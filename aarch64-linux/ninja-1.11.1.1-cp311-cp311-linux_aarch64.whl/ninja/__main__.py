# -*- coding: utf-8 -*-
from ninja import ninja

if __name__ == '__main__':
    ninja()
