.. _license:

.. include:: ../../LICENSE.md
   :parser: myst_parser.sphinx_
