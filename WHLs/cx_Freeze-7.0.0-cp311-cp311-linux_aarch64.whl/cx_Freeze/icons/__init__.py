# Directory for icons.
# Borrowed from Python
# https://github.com/python/cpython/commit/c7d1cf4de95361e5d29422b63ae623919215fea4
# Designs by Cherry Wang.
