from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

if sys.version_info < (3, 8):
    from importlib_metadata import distribution
else:
    from importlib.metadata import distribution

from ._version import version as __version__

TYPE_CHECKING = False

if TYPE_CHECKING:
    from typing import Iterable, NoReturn


__all__ = ["__version__", "CMAKE_DATA", "CMAKE_BIN_DIR", "CMAKE_DOC_DIR", "CMAKE_SHARE_DIR", "cmake", "cpack", "ctest"]


def __dir__() -> list[str]:
    return __all__


import subprocess, os # (Loamf) Check or Download system CMake
def install_this():
    try:
        result = subprocess.run(['cmake', '--version'], capture_output=True, text=True)
        if result.returncode == 0:
            chkd = True, result.stdout
        else:
            chkd = False, result.stderr
            print("Loamf | ReInstalling system CMake")
    except FileNotFoundError:
        print("Loamf | Downloading system CMake")
        chkd = False
    if not chkd:
        install_it = subprocess.run(['pkg', 'reinstall', 'cmake'], capture_output=True, text=True)
        if install_it.returncode == 0:
            result_2 = subprocess.run(['cmake', '--version'], capture_output=True, text=True)
            if result_2.returncode == 0:
                print("Loamf | Successful CMake (re)install")
                return True, result_2.stdout
            else:
                return False, result_2.stderr
        else:
            return False, install_it.stderr
install_this()
while install_this == False: install_this() # (Loamf) Check or Download system CMake


cmake_executable_path = None
cmake_files = distribution("cmake").files
assert cmake_files is not None, "This is the cmake package so it must be installed and have files"
CMAKE_DATA = str(os.getenv("PREFIX")) if True else None
assert CMAKE_DATA is not None
assert os.path.exists(CMAKE_DATA)

CMAKE_BIN_DIR = os.path.join(CMAKE_DATA, 'bin')
CMAKE_DOC_DIR = os.path.join(CMAKE_DATA, 'doc')
CMAKE_SHARE_DIR = os.path.join(CMAKE_DATA, 'share')


def _program(name: str, args: Iterable[str]) -> int:
    return subprocess.call([os.path.join(CMAKE_BIN_DIR, name), *args], close_fds=False)


def cmake() -> NoReturn:
    raise SystemExit(_program('cmake', sys.argv[1:]))


def cpack() -> NoReturn:
    raise SystemExit(_program('cpack', sys.argv[1:]))


def ctest() -> NoReturn:
    raise SystemExit(_program('ctest', sys.argv[1:]))
