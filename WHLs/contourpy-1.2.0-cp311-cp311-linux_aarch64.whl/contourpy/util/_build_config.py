# _build_config.py.in is converted into _build_config.py during the meson build process.

from __future__ import annotations


def build_config() -> dict[str, str]:
    """
    Return a dictionary containing build configuration settings.

    All dictionary keys and values are strings, for example ``False`` is
    returned as ``"False"``.

        .. versionadded:: 1.1.0
    """
    return dict(
        # Python settings
        python_version="3.11",
        python_install_dir=r"/usr/local/lib/python3.11/site-packages/",
        python_path=r"/data/data/com.termux/files/usr/bin/python3.11",

        # Package versions
        contourpy_version="1.2.0",
        meson_version="1.3.0",
        mesonpy_version="0.15.0",
        pybind11_version="2.11.1",

        # Misc meson settings
        meson_backend="ninja",
        build_dir=r"/data/data/com.termux/files/usr/tmp/pip-install-_1c_kgp1/contourpy_10f1300c360b4a1e9d7751f23a746e0a/.mesonpy-6fz3vi9_/lib/contourpy/util",
        source_dir=r"/data/data/com.termux/files/usr/tmp/pip-install-_1c_kgp1/contourpy_10f1300c360b4a1e9d7751f23a746e0a/lib/contourpy/util",
        cross_build="0",

        # Build options
        build_options=r"-Dbuildtype=release -Db_ndebug=if-release -Db_vscrt=md -Dvsenv=True --native-file=/data/data/com.termux/files/usr/tmp/pip-install-_1c_kgp1/contourpy_10f1300c360b4a1e9d7751f23a746e0a/.mesonpy-6fz3vi9_/meson-python-native-file.ini",
        buildtype="release",
        cpp_std="c++17",
        debug="0",
        optimization="3",
        vsenv="1",
        b_ndebug="if-release",
        b_vscrt="from_buildtype",

        # C++ compiler
        compiler_name="clang",
        compiler_version="17.0.6",
        linker_id="ld.lld",
        compile_command="c++",

        # Host machine
        host_cpu="aarch64",
        host_cpu_family="aarch64",
        host_cpu_endian="little",
        host_cpu_system="linux",

        # Build machine, same as host machine if not a cross_build
        build_cpu="aarch64",
        build_cpu_family="aarch64",
        build_cpu_endian="little",
        build_cpu_system="linux",
    )
